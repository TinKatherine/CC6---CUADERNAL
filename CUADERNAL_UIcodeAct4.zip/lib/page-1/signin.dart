import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'dashboard.dart';
import 'signup.dart';

class SignInScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // signinDFf (3:5)
        padding: EdgeInsets.fromLTRB(0 * fem, 75 * fem, 0 * fem, 85 * fem),
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
          image: DecorationImage(
            fit: BoxFit.cover,
            image: AssetImage(
              'assets/page-1/images/image-2-bg-G65.png',
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // zumbaVys (3:7)
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 44 * fem, 40 * fem),
              child: Text(
                'ZUMBA!!!',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Irish Grover',
                  fontSize: 60 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 0.5444413795 * ffem / fem,
                  color: Color(0xff1e1e1e),
                ),
              ),
            ),
            Container(
              // zumbaQL9 (3:15)
              margin: EdgeInsets.fromLTRB(37 * fem, 0 * fem, 0 * fem, 41 * fem),
              child: Text(
                'ZUMBA!!!',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Irish Grover',
                  fontSize: 60 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 0.5444413795 * ffem / fem,
                  color: Color(0xff1e1e1e),
                ),
              ),
            ),
            Container(
              // zumbagYZ (3:17)
              margin: EdgeInsets.fromLTRB(94 * fem, 0 * fem, 0 * fem, 71 * fem),
              child: Text(
                'ZUMBA!!!',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Irish Grover',
                  fontSize: 60 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 0.5444413795 * ffem / fem,
                  color: Color(0xff1e1e1e),
                ),
              ),
            ),
            Container(
              // username1Kw (3:20)
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 1 * fem, 8 * fem),
              child: Text(
                'USERNAME',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Imprima',
                  fontSize: 24 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.5980000496 * ffem / fem,
                  letterSpacing: 3.84 * fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Container(
              // rectangle1jFw (3:18)
              margin:
                  EdgeInsets.fromLTRB(42 * fem, 0 * fem, 43 * fem, 31 * fem),
              width: double.infinity,
              height: 45 * fem,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(13 * fem),
                color: Color(0xfffcf1df),
              ),
              child: TextField(
                // Add properties for the username input
                decoration: InputDecoration(
                  hintText: 'Enter your username',
                  contentPadding: EdgeInsets.symmetric(horizontal: 16),
                  border: InputBorder.none,
                ),
              ),
            ),
            Container(
              // passwordTxd (3:21)
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 1 * fem, 7 * fem),
              child: Text(
                'PASSWORD',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Imprima',
                  fontSize: 24 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.5980000496 * ffem / fem,
                  letterSpacing: 3.84 * fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Container(
              // rectangle2nk1 (3:19)
              margin:
                  EdgeInsets.fromLTRB(43 * fem, 0 * fem, 42 * fem, 29 * fem),
              width: double.infinity,
              height: 45 * fem,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(13 * fem),
                color: Color(0xfffdf2df),
              ),
              child: TextField(
                // Add properties for the password input
                obscureText: true,
                decoration: InputDecoration(
                  hintText: 'Enter your password',
                  contentPadding: EdgeInsets.symmetric(horizontal: 16),
                  border: InputBorder.none,
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                // Handle sign-in button tap here
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DashboardScreen()),
                );
              },
              child: Container(
                // autogroupmi2uWAD (3bo32fqWZz3MMSVBC5mi2u)
                margin:
                    EdgeInsets.fromLTRB(79 * fem, 0 * fem, 78 * fem, 16 * fem),
                width: double.infinity,
                height: 74 * fem,
                decoration: BoxDecoration(
                  color: Color(0xffd6af25),
                  borderRadius: BorderRadius.circular(50 * fem),
                ),
                child: Center(
                  child: Text(
                    'SIGN-IN',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont(
                      'Hepta Slab',
                      fontSize: 24 * ffem,
                      fontWeight: FontWeight.w800,
                      height: 1.3929999669 * ffem / fem,
                      letterSpacing: 3.6 * fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                // Handle sign up button tap here
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SignupScreen()),
                );
              },
              child: Container(
                // autogroupjfoxndX (3bo37arzK4LdMoFvfBjFoX)
                margin:
                    EdgeInsets.fromLTRB(60 * fem, 0 * fem, 61 * fem, 0 * fem),
                width: double.infinity,
                height: 23 * fem,
                child: Stack(
                  children: [
                    Positioned(
                      // donthaveanaccountTzZ (3:42)
                      left: 0 * fem,
                      top: 2 * fem,
                      child: Align(
                        child: SizedBox(
                          width: 239 * fem,
                          height: 21 * fem,
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont(
                                'Hepta Slab',
                                fontSize: 15 * ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.3930000305 * ffem / fem,
                                letterSpacing: 2.25 * fem,
                                color: Color(0xff000000),
                              ),
                              children: [
                                TextSpan(
                                  text: 'Sign up',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
