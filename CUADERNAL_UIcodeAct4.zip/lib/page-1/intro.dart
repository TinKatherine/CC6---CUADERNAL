import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'signin.dart';

class IntroScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // introVJH (1:2)
        padding: EdgeInsets.fromLTRB(0 * fem, 100 * fem, 0 * fem, 153 * fem),
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
          image: DecorationImage(
            image: AssetImage(
              'assets/page-1/images/image-1-bg.png',
            ),
            fit: BoxFit.cover, // Make the background image fit the frame
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupxj17o45 (3bo3NpvbF2vYwMF8bkxJ17)
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 0 * fem, 44 * fem),
              width: double.infinity,
              height: 429 * fem,
              child: Stack(
                children: [
                  Positioned(
                    // letsgozumba63B (2:5)
                    left: 0 * fem,
                    top: 0 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 402 * fem,
                        height: 279 * fem,
                        child: RichText(
                          textAlign: TextAlign.center,
                          text: TextSpan(
                            style: SafeGoogleFont(
                              'Irish Grover',
                              fontSize: 70 * ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.21 * ffem / fem,
                              color: Color(0xffffffff),
                            ),
                            children: [
                              TextSpan(
                                text: 'LET’S \nGO ',
                              ),
                              TextSpan(
                                text: 'ZUMBA!!!',
                                style: SafeGoogleFont(
                                  'Irish Grover',
                                  fontSize: 80 * ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.21 * ffem / fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // boostyourmoodwithzumbabeoneofu (3:2)
                    left: 31 * fem,
                    top: 275 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 311 * fem,
                        height: 154 * fem,
                        child: Text(
                          'Boost Your Mood with Zumba\nBE ONE OF US!.',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont(
                            'Imprima',
                            fontSize: 32 * ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.6007599976 * ffem / fem,
                            letterSpacing: 5.12 * fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SignInScreen(),
                  ),
                );
              },
              child: Container(
                // autogroupkrhxsrZ (3bo3Sue89X511aZcqRKrHX)
                margin:
                    EdgeInsets.fromLTRB(79 * fem, 0 * fem, 78 * fem, 0 * fem),
                width: double.infinity,
                height: 74 * fem,
                decoration: BoxDecoration(
                  color: Color(0xffd6af25),
                  borderRadius: BorderRadius.circular(50 * fem),
                ),
                child: Center(
                  child: Text(
                    'JOIN NOW',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont(
                      'Hepta Slab',
                      fontSize: 24 * ffem,
                      fontWeight: FontWeight.w800,
                      height: 1.3929999669 * ffem / fem,
                      letterSpacing: 3.6 * fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
