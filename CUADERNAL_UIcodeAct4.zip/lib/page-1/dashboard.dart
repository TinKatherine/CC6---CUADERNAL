import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

import 'location.dart'; // Import the location.dart file
import 'intro.dart'; // Import the intro.dart file

class DashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        padding: EdgeInsets.fromLTRB(0 * fem, 15 * fem, 0 * fem, 70.08 * fem),
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
          image: DecorationImage(
            fit: BoxFit.cover,
            image: AssetImage(
              'assets/page-1/images/image-3-bg-HUD.png',
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 44 * fem, 40 * fem),
              width: 334 * fem,
              height: 81 * fem,
              child: Stack(
                children: [
                  Positioned(
                    left: 0 * fem,
                    top: 37 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 334 * fem,
                        height: 44 * fem,
                        child: Text(
                          'ZUMBA!!!',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont(
                            'Irish Grover',
                            fontSize: 60 * ffem,
                            fontWeight: FontWeight.w400,
                            height: 0.5444413795 * ffem / fem,
                            color: Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 20 * fem,
                    top: 0 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 55 * fem,
                        height: 55 * fem,
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(27.5 * fem),
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 25 * fem,
                    top: 5 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 45 * fem,
                        height: 45 * fem,
                        child: InkWell(
                          onTap: () {
                            // Navigate to intro.dart on arrow circle left press
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => IntroScreen()),
                            );
                          },
                          child: Image.asset(
                            'assets/page-1/images/icon-arrow-circle-left.png',
                            width: 45 * fem,
                            height: 45 * fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(37 * fem, 0 * fem, 0 * fem, 41 * fem),
              child: Text(
                'ZUMBA!!!',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Irish Grover',
                  fontSize: 60 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 0.5444413795 * ffem / fem,
                  color: Color(0xff1e1e1e),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(94 * fem, 0 * fem, 0 * fem, 29 * fem),
              child: Text(
                'ZUMBA!!!',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Irish Grover',
                  fontSize: 60 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 0.5444413795 * ffem / fem,
                  color: Color(0xff1e1e1e),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 1 * fem, 21 * fem),
              constraints: BoxConstraints(
                maxWidth: 322 * fem,
              ),
              child: Text(
                'All types of exercise come with life-improving benefits. Whether they impact your life physically, mentally or socially, exercise should be an essential part of your life because of the positive impact it can make on you. Of course, it\'s helpful to find a type of exercise that you enjoy and can easily incorporate into your weekly routine. If you\'re the type of person who prefers group exercise and loves to dance, Zumba® is the perfect class for you.',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Hepta Slab',
                  fontSize: 15 * ffem,
                  fontWeight: FontWeight.w500,
                  height: 1.5629999797 * ffem / fem,
                  letterSpacing: 2.25 * fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Container(
              margin:
                  EdgeInsets.fromLTRB(0 * fem, 0 * fem, 0.38 * fem, 0 * fem),
              width: 23.62 * fem,
              height: 38.92 * fem,
              child: InkWell(
                onTap: () {
                  // Navigate to location.dart on chevron right press
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => LocationScreen()),
                  );
                },
                child: Image.asset(
                  'assets/page-1/images/icon-chevron-right.png',
                  width: 23.62 * fem,
                  height: 38.92 * fem,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
