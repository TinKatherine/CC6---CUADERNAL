import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'intro.dart';
import 'dashboard.dart';

class LocationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // locationnLy (4:123)
        padding: EdgeInsets.fromLTRB(0 * fem, 13 * fem, 0 * fem, 75.08 * fem),
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
          image: DecorationImage(
            fit: BoxFit.cover,
            image: AssetImage(
              'assets/page-1/images/image-3-bg.png',
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupu77fHqT (3bo1jdADtXjHmTniQqU77f)
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 44 * fem, 40 * fem),
              width: 334 * fem,
              height: 83 * fem,
              child: Stack(
                children: [
                  Positioned(
                    // zumbaBR3 (4:125)
                    left: 0 * fem,
                    top: 39 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 334 * fem,
                        height: 44 * fem,
                        child: Text(
                          'ZUMBA!!!',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont(
                            'Irish Grover',
                            fontSize: 60 * ffem,
                            fontWeight: FontWeight.w400,
                            height: 0.5444413795 * ffem / fem,
                            color: Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse2ZwP (4:149)
                    left: 23 * fem,
                    top: 0 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 55 * fem,
                        height: 55 * fem,
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(27.5 * fem),
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // iconarrowcircleleftTms (4:150)
                    left: 28 * fem,
                    top: 5 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 45 * fem,
                        height: 45 * fem,
                        child: TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => IntroScreen()),
                            );
                          },
                          style: TextButton.styleFrom(
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/page-1/images/icon-arrow-circle-left-zkh.png',
                            width: 45 * fem,
                            height: 45 * fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // zumbaged (4:126)
              margin: EdgeInsets.fromLTRB(37 * fem, 0 * fem, 0 * fem, 41 * fem),
              child: Text(
                'ZUMBA!!!',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Irish Grover',
                  fontSize: 80 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 0.5444413795 * ffem / fem,
                  color: Color(0xff1e1e1e),
                ),
              ),
            ),
            Container(
              // zumbazvD (4:127)
              margin: EdgeInsets.fromLTRB(94 * fem, 0 * fem, 0 * fem, 86 * fem),
              child: Text(
                'ZUMBA!!!',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Irish Grover',
                  fontSize: 80 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 0.5444413795 * ffem / fem,
                  color: Color(0xff1e1e1e),
                ),
              ),
            ),
            Container(
              // citymallboulevardroxascitycapi (4:129)
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 1 * fem, 25 * fem),
              constraints: BoxConstraints(
                maxWidth: 273 * fem,
              ),
              child: Text(
                '@ CITY MALL, BOULEVARD, ROXAS CITY, CAPIZ',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Hepta Slab',
                  fontSize: 20 * ffem,
                  fontWeight: FontWeight.w500,
                  height: 1.5629999161 * ffem / fem,
                  letterSpacing: 3 * fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Container(
              // smsupermallcityroxasYaM (4:130)
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 1 * fem, 27 * fem),
              constraints: BoxConstraints(
                maxWidth: 258 * fem,
              ),
              child: Text(
                '@ SM SUPER MALL CITY ROXAS',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Hepta Slab',
                  fontSize: 20 * ffem,
                  fontWeight: FontWeight.w500,
                  height: 1.5629999161 * ffem / fem,
                  letterSpacing: 3 * fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Container(
              // kristineccuadernalbsit3azhF (101:16)
              margin: EdgeInsets.fromLTRB(6 * fem, 0 * fem, 0 * fem, 96 * fem),
              constraints: BoxConstraints(
                maxWidth: 146 * fem,
              ),
              child: Text(
                'KRISTINE C. CUADERNAL\nBSIT 3A',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Inter',
                  fontSize: 12 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.2125 * ffem / fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DashboardScreen()),
                );
              },
              child: Container(
                // iconchevronrightPDb (101:22)
                width: 20 * fem,
                height: 38.92 * fem,
                child: Image.asset(
                  'assets/page-1/images/icon-chevron-right-7QD.png',
                  width: 20 * fem,
                  height: 38.92 * fem,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
