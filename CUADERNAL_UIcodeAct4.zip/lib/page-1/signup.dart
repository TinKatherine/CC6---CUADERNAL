import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

import 'signin.dart'; // Import the login.dart file

class SignupScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        padding: EdgeInsets.fromLTRB(0 * fem, 52 * fem, 0 * fem, 91 * fem),
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
          image: DecorationImage(
            fit: BoxFit.cover,
            image: AssetImage(
              'assets/page-1/images/image-2-bg.png',
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 44 * fem, 40 * fem),
              child: Text(
                'ZUMBA!!!',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Irish Grover',
                  fontSize: 60 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 0.5444413795 * ffem / fem,
                  color: Color(0xff1e1e1e),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(37 * fem, 0 * fem, 0 * fem, 41 * fem),
              child: Text(
                'ZUMBA!!!',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Irish Grover',
                  fontSize: 60 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 0.5444413795 * ffem / fem,
                  color: Color(0xff1e1e1e),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(94 * fem, 0 * fem, 0 * fem, 41 * fem),
              child: Text(
                'ZUMBA!!!',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Irish Grover',
                  fontSize: 60 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 0.5444413795 * ffem / fem,
                  color: Color(0xff1e1e1e),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 1 * fem, 7 * fem),
              child: Text(
                'USERNAME',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Imprima',
                  fontSize: 20 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.5980000496 * ffem / fem,
                  letterSpacing: 3.2 * fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Container(
              margin:
                  EdgeInsets.fromLTRB(42 * fem, 0 * fem, 43 * fem, 20 * fem),
              width: double.infinity,
              height: 38 * fem,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(13 * fem),
                color: Color(0xfffcf1df),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 1 * fem, 3 * fem),
              child: Text(
                'PASSWORD',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Imprima',
                  fontSize: 20 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.5980000496 * ffem / fem,
                  letterSpacing: 3.2 * fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Container(
              margin:
                  EdgeInsets.fromLTRB(42 * fem, 0 * fem, 43 * fem, 22 * fem),
              width: double.infinity,
              height: 38 * fem,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(13 * fem),
                color: Color(0xfffcf1df),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 0 * fem, 5 * fem),
              child: Text(
                'RE-TYPE PASSWORD',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Imprima',
                  fontSize: 20 * ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.5980000496 * ffem / fem,
                  letterSpacing: 3.2 * fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Container(
              margin:
                  EdgeInsets.fromLTRB(42 * fem, 0 * fem, 43 * fem, 24 * fem),
              width: double.infinity,
              height: 38 * fem,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(13 * fem),
                color: Color(0xfffcf1df),
              ),
            ),
            Container(
              margin:
                  EdgeInsets.fromLTRB(78 * fem, 0 * fem, 79 * fem, 17 * fem),
              width: double.infinity,
              height: 74 * fem,
              decoration: BoxDecoration(
                color: Color(0xffd6af25),
                borderRadius: BorderRadius.circular(50 * fem),
              ),
              child: Center(
                child: Text(
                  'SIGN-UP',
                  textAlign: TextAlign.center,
                  style: SafeGoogleFont(
                    'Hepta Slab',
                    fontSize: 24 * ffem,
                    fontWeight: FontWeight.w800,
                    height: 1.3929999669 * ffem / fem,
                    letterSpacing: 3.6 * fem,
                    color: Color(0xff000000),
                  ),
                ),
              ),
            ),
            Container(
              margin:
                  EdgeInsets.fromLTRB(47.5 * fem, 0 * fem, 48.5 * fem, 0 * fem),
              width: double.infinity,
              height: 42 * fem,
              child: Stack(
                children: [
                  Positioned(
                    left: 0 * fem,
                    top: 0 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 264 * fem,
                        height: 21 * fem,
                        child: TextButton(
                          onPressed: () {
                            // Navigate to login.dart on sign-up button press
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => SignInScreen()),
                            );
                          },
                          style: TextButton.styleFrom(
                            padding: EdgeInsets.zero,
                          ),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont(
                                'Hepta Slab',
                                fontSize: 15 * ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.3930000305 * ffem / fem,
                              ),
                              children: [
                                TextSpan(
                                  text: '\n',
                                  style: SafeGoogleFont(
                                    'Hepta Slab',
                                    fontSize: 15 * ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.3930000305 * ffem / fem,
                                  ),
                                ),
                                TextSpan(
                                  text: 'Sign Up',
                                  style: SafeGoogleFont(
                                    'Hepta Slab',
                                    fontSize: 15 * ffem,
                                    fontWeight: FontWeight.w800,
                                    height: 1.3930000305 * ffem / fem,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 0 * fem,
                    top: 21 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 264 * fem,
                        height: 21 * fem,
                        child: TextButton(
                          onPressed: () {
                            // Navigate to login.dart on sign-in text press
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => SignInScreen()),
                            );
                          },
                          style: TextButton.styleFrom(
                            padding: EdgeInsets.zero,
                          ),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont(
                                'Hepta Slab',
                                fontSize: 15 * ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.3930000305 * ffem / fem,
                                color: Colors.white,
                              ),
                              children: [
                                TextSpan(
                                  text: 'Sign In',
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
